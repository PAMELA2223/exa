export const firebaseConfig = {
  apiKey: "AIzaSyD8NOveaRTy66gCDNbZWx33i79NEt2cZdA",
  authDomain: "practicas-de-angular.firebaseapp.com",
  projectId: "practicas-de-angular",
  storageBucket: "practicas-de-angular.appspot.com",
  messagingSenderId: "409645216058",
  appId: "1:409645216058:web:f80d042411ffaf90cca003",
  measurementId: "G-Z0HJQ85LCK"
};